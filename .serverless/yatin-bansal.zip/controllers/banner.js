const banner = require('../models/banner')



exports.AddBanner = async (req, res) => {
    try {
        if (req.file) {
            req.body.image = req.file.path
        }
        const data = {
            image: req.body.image,
            desc: req.body.desc
        }
        const Data = await banner.create(data);
        return res.status(200).json({
            message: "Banner is Addded ",
            data: Data
        })
    } catch (err) {
        console.log(err);
        return res.status(400).json({
            message: err.message
        })
    }
}

exports.getBanner = async (req, res) => {
    try {
        const Banner = await banner.find();
        return res.status(200).json({
            message: "All Banners",
            data: Banner
        })
    } catch (err) {
        console.log(err);
        return res.status(400).json({
            message: err.message
        })
    }
}

exports.getById = async (req, res) => {
    try {
        const Banner = await banner.findById({ _id: req.params.id });
        return res.status(200).json({
            message: "One Banners",
            data: Banner
        })
    } catch (err) {
        console.log(err);
        return res.status(400).json({
            message: err.message
        })
    }
}

exports.DeleteBanner = async (req, res) => {
    try {
        const Banner = await banner.findByIdAndDelete({ _id: req.params.id });
        return res.status(200).json({
            message: "Delete Banner ",
        },)
    } catch (err) {
        return res.status(400).json({
            message: err.message
        })
    }
}